import json

import boto3
import os

import requests

ssm_client = boto3.client('ssm')
lambda_client = boto3.client('lambda')

webhooks_arns = os.getenv('WEBHOOKS').split(',')
formatter_lambdas = os.getenv('FORMATTER_LAMBDAS', '').split(',')
webhooks = []
for webhook_arn in webhooks_arns:
    param = ssm_client.get_parameter(Name=webhook_arn, WithDecryption=True)
    webhooks.append(param['Parameter']['Value'])


def lambda_handler(event, context):
    global webhooks
    messages = list(map(lambda x: x['Sns']['Message'], event['Records']))
    for webhook in webhooks:
        for message in messages:
            formatted = False
            for formatter in formatter_lambdas:
                response = lambda_client.invoke(
                    FunctionName=formatter,
                    InvocationType='RequestResponse',
                    Payload=json.dumps({'message': message})
                )
                result_payload = json.load(response['Payload'])
                if result_payload['ignore']:
                    return
                if result_payload['formatted']:
                    requests.post(webhook, json={
                        'text': result_payload['message']})
                    formatted = True
                    break

            if not formatted:
                requests.post(webhook, json={'text': message})


if __name__ == '__main__':
    # test_msg = '{"AlarmName":"example-dev-example-dev-test-cpu-credit-balance-low","AlarmDescription":"Average database CPU credit balance over last 10 minutes too low, expect a significant performance drop soon","AWSAccountId":"123456789","AlarmConfigurationUpdatedTimestamp":"2024-03-08T14:05:02.761+0000","NewStateValue":"ALARM","NewStateReason":"Threshold Crossed: 1 datapoint [0.0 (08/03/24 13:56:00)] was less than the threshold (20.0).","StateChangeTime":"2024-03-08T14:06:01.853+0000","Region":"US East (N. Virginia)","AlarmArn":"arn:aws:cloudwatch:us-east-1:123456789012:alarm:example-dev-example-dev-test-cpu-credit-balance-low","OldStateValue":"INSUFFICIENT_DATA","OKActions":["arn:aws:sns:us-east-1:123456789012:example-dev-example-dev-test-ok-rds-threshold-alerts20240308140459771500000003"],"AlarmActions":["arn:aws:sns:us-east-1:123456789012:example-dev-notifications"],"InsufficientDataActions":[],"Trigger":{"MetricName":"CPUCreditBalance","Namespace":"AWS/RDS","StatisticType":"Statistic","Statistic":"AVERAGE","Unit":null,"Dimensions":[{"value":"example-dev-test","name":"DBInstanceIdentifier"}],"Period":600,"EvaluationPeriods":1,"ComparisonOperator":"LessThanThreshold","Threshold":20.0,"TreatMissingData":"missing","EvaluateLowSampleCountPercentile":""}}'
    test_msg = '{"version":"0","id":"e26d4f75-6bbc-ecaf-d75f-046305d222d9","detail-type":"AWS API Call via CloudTrail","source":"aws.iam","account":"322231848625","time":"2025-10-03T08:41:04Z","region":"us-east-1","resources":[],"detail":{"eventVersion":"1.11","userIdentity":{"type":"AssumedRole","principalId":"AROAUWBUDZ2YWRNRVSP5J:marek.moscichowski@miquido.com","arn":"arn:aws:sts::322231848625:assumed-role/AdministratorAccess/marek.moscichowski@miquido.com","accountId":"322231848625","accessKeyId":"ASIAUWBUDZ2YXEDOUSTL","sessionContext":{"sessionIssuer":{"type":"Role","principalId":"AROAUWBUDZ2YWRNRVSP5J","arn":"arn:aws:iam::322231848625:role/AdministratorAccess","accountId":"322231848625","userName":"AdministratorAccess"},"attributes":{"creationDate":"2025-10-03T08:40:44Z","mfaAuthenticated":"true"}},"invokedBy":"resource-explorer-2.amazonaws.com"},"eventTime":"2025-10-03T08:41:04Z","eventSource":"iam.amazonaws.com","eventName":"CreateServiceLinkedRole","awsRegion":"us-east-1","sourceIPAddress":"resource-explorer-2.amazonaws.com","userAgent":"resource-explorer-2.amazonaws.com","requestParameters":{"aWSServiceName":"resource-explorer-2.amazonaws.com"},"responseElements":{"role":{"path":"/aws-service-role/resource-explorer-2.amazonaws.com/","roleName":"AWSServiceRoleForResourceExplorer","roleId":"AROAUWBUDZ2Y3CEZGVVPL","arn":"arn:aws:iam::322231848625:role/aws-service-role/resource-explorer-2.amazonaws.com/AWSServiceRoleForResourceExplorer","createDate":"Oct 3, 2025, 8:41:04 AM","assumeRolePolicyDocument":"%7B%22Version%22%3A%20%222012-10-17%22%2C%20%22Statement%22%3A%20%5B%7B%22Action%22%3A%20%5B%22sts%3AAssumeRole%22%5D%2C%20%22Effect%22%3A%20%22Allow%22%2C%20%22Principal%22%3A%20%7B%22Service%22%3A%20%5B%22resource-explorer-2.amazonaws.com%22%5D%7D%7D%5D%7D"}},"requestID":"c957e852-48dd-4839-88ce-e1cd8de9dc97","eventID":"d91b36b6-016e-44c1-a0e0-47d7b4289926","readOnly":false,"eventType":"AwsApiCall","managementEvent":true,"recipientAccountId":"322231848625","eventCategory":"Management","sessionCredentialFromConsole":"true"}}'

    e = {'Records': [
        {
            'Sns': {
                'Message': test_msg
            }
        },
        {
            'Sns': {
                'Message': 'Drugi message'
            }
        }
    ]}
    lambda_handler(e, None)
